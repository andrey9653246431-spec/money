# Деньги без паники — дизайн-завод

GitHub-ready генератор фирменных карточек для Telegram- и MAX-канала **«Деньги без паники»**. Превращает JSON контент-завода в PNG **1080×1350**, не требует API-ключей и поддерживает кириллицу.

![Примеры карточек](examples/previews/contact-sheet.png)

## Возможности

- Три макета: утренний мем, дневной разбор, спокойный вечер.
- Звёздная вариация вечернего макета для финансового гороскопа.
- Единая палитра и фирменный шрифт **Manrope** (SIL OFL).
- Короткий `card`-контент вместо переноса всего поста на картинку.
- Автоматический перенос строк и подбор размера шрифта.
- Ошибка вместо молчаливого обрезания слишком длинного текста.
- `manifest.json` с content ID, alt-текстом, AI-промптом и SHA-256.
- Генератор аватара 1024×1024.
- Автотесты, Ruff, GitHub Actions и Dependabot.

Это **основной template-трек**. Отдельно приложены промпты для внешнего генератора AI-иллюстраций; сам репозиторий не отправляет данные внешним сервисам и не хранит их ключи.

## Быстрый старт

Нужен Python 3.11+.

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -e ".[dev]"

dbp-design validate --input examples/posts.json
dbp-design build --input examples/posts.json --out dist
dbp-design avatar --out dist/avatar.png
```

Результат:

```text
dist/
├── 001_morning.png
├── 002_day.png
├── 003_evening.png
├── avatar.png
└── manifest.json
```

Без установки console script можно запускать `python -m design_factory ...` из корня репозитория после установки зависимостей.

## Формат входа

```json
{
  "date": "2026-11-12",
  "posts": [
    {
      "content_id": "2026-11-12-day",
      "slot": "day",
      "rubric": "Разбор акции",
      "card": {
        "title": "Скидка 50% — ещё не выгода",
        "subtitle": "Сначала проверь полные условия.",
        "badge": "РАЗБОР АКЦИИ",
        "points": [
          "Сопоставь обычную цену",
          "Добавь доставку",
          "Реши, нужна ли вещь без скидки"
        ],
        "footer": "Спокойная проверка вместо импульсивной покупки."
      },
      "image_prompt": "Промпт отдельной AI-иллюстрации",
      "alt_text": "Карточка проверки скидки"
    }
  ]
}
```

Ограничения: `slot` = `morning`, `day` или `evening`; на карточке не более трёх пунктов. Полная схема — `schemas/content.schema.json`. `working_title` используется как fallback, если нет `card.title`.

**Не помещайте полный пост в карточку.** Для сокращения используйте `prompts/art-director.md`, затем проверьте, что смысл не изменился. Полные условия акции, дисклеймеры и ссылки остаются в тексте публикации.

## Команды

```bash
# Проверка данных и ресурсов
dbp-design validate -i examples/posts.json

# Генерация всех карточек и manifest
dbp-design build -i examples/posts.json -o dist/2026-11-12

# Отдельный пример звёздной карточки гороскопа
dbp-design build -i examples/horoscope.json -o dist/horoscope

# Аватар
dbp-design avatar -o dist/avatar.png

# Проверка кода
ruff check .
pytest
```

Или через Makefile: `make install`, `make check`, `make build`, `make avatar`.

## Настройка бренда

Все цвета, размер холста, название и путь к шрифту находятся в `brand/tokens.json`. Композиции — `design_factory/renderer.py`.

Перед сменой шрифта:

1. Проверьте поддержку кириллицы.
2. Добавьте файл с разрешающей лицензией.
3. Обновите `THIRD_PARTY_NOTICES.md`.
4. Запустите примеры и визуально проверьте переполнения.

## Интеграция с контент-заводом

```text
Пост → арт-директор → card JSON → validate → PNG → визуальный review
→ редакторский approval → Telegram / MAX
```

Подробнее: [`docs/INTEGRATION.md`](docs/INTEGRATION.md). Публикационный сервис должен использовать `content_id + platform` как ключ идемпотентности.

## GitHub

Инструкция по созданию репозитория и первому push: [`docs/GITHUB_SETUP.md`](docs/GITHUB_SETUP.md).

Workflow `.github/workflows/ci.yml` запускается на push/pull request, тестирует Python 3.11–3.13, собирает примеры и сохраняет их как artifact. Никакие секреты для CI не нужны.

## Структура

```text
assets/fonts/           Manrope + OFL
brand/tokens.json       Дизайн-токены
design_factory/         CLI, модели, вёрстка и рендеринг
docs/                   GitHub и интеграция
examples/               Входной JSON и превью
prompts/                Арт-директор и AI-иллюстрации
schemas/                JSON Schema
tests/                  Автотесты
.github/                CI, Dependabot, PR checklist
```

## Лицензии

Код — MIT (`LICENSE`). Шрифт Manrope — SIL Open Font License 1.1; уведомления сохранены в `assets/fonts/OFL.txt` и `THIRD_PARTY_NOTICES.md`. Перед публикацией замените copyright владельца в `LICENSE`, если требуется.
