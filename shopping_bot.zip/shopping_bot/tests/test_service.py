from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from app.catalog import Catalog, CatalogError
from app.database import Database
from app.service import ShoppingService
from app.text import split_message

ROOT = Path(__file__).resolve().parents[1]


class ShoppingServiceTest(unittest.TestCase):
    def setUp(self) -> None:
        self.database = Database(":memory:")
        self.catalog = Catalog(ROOT / "data" / "catalog.csv")
        self.service = ShoppingService(self.database, self.catalog)

    def test_add_merge_list_and_remove(self) -> None:
        self.assertIn("Добавлено", self.service.handle("u1", "/add молоко 3,2%"))
        self.service.handle("u1", "/add 2 молоко 3,2%")
        self.service.handle("u1", "/add хлеб")
        items = self.database.items("u1")
        self.assertEqual(len(items), 2)
        self.assertEqual(items[0].quantity, 3)
        self.assertIn("Осталось купить: 2 из 2", self.service.handle("u1", "/list"))
        self.service.handle("u1", f"/bought {items[0].id}")
        self.assertIn("✅", self.service.handle("u1", "/list"))
        self.service.handle("u1", f"/remove {items[1].id}")
        self.assertEqual(len(self.database.items("u1")), 1)

    def test_users_are_isolated(self) -> None:
        self.service.handle("u1", "/add рис")
        self.service.handle("u2", "/add кофе")
        self.assertIn("рис", self.service.handle("u1", "/list"))
        self.assertNotIn("кофе", self.service.handle("u1", "/list"))

    def test_comparison_is_explicitly_demo(self) -> None:
        response = self.service.handle("u1", "/compare молоко 3,2%")
        self.assertIn("ДЕМО-ЦЕНЫ", response)
        self.assertIn("Пятёрочка", response)
        self.assertIn("Глобус", response)
        self.assertIn("2000-01-01", response)

    def test_total_uses_quantities(self) -> None:
        self.service.handle("u1", "/add 2 молоко 3,2%")
        response = self.service.handle("u1", "/total")
        self.assertIn("177,00 ₽", response)  # Cheapest demo offer: 2 × 88.50.
        self.assertIn("Минимум по позициям", response)

    def test_send_and_clear(self) -> None:
        self.service.handle("u1", "Добавь бананы")
        self.assertIn("Ваш список покупок", self.service.handle("u1", "/send"))
        self.assertIn("Ваш список покупок", self.service.handle("u1", "отправь список"))
        self.service.handle("u1", "/clear")
        self.assertIn("Список пуст", self.service.handle("u1", "/list"))

    def test_invalid_catalog_price(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "bad.csv"
            path.write_text(
                "store,product,package,price_rub,old_price_rub,url,updated_at,is_demo\n"
                "A,B,1 л,not-a-price,,,2026-01-01,false\n",
                encoding="utf-8",
            )
            with self.assertRaises(CatalogError):
                Catalog(path)

    def test_message_split(self) -> None:
        chunks = split_message("a\n" * 100, limit=20)
        self.assertTrue(all(len(chunk) <= 20 for chunk in chunks))
        self.assertEqual("".join(chunks).count("a"), 100)


if __name__ == "__main__":
    unittest.main()
