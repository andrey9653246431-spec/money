from __future__ import annotations

import argparse
import asyncio
import logging
import os
from pathlib import Path

from dotenv import load_dotenv

from app.catalog import Catalog
from app.database import Database
from app.service import ShoppingService


def ids_from_env(name: str) -> set[int]:
    result: set[int] = set()
    for raw in os.getenv(name, "").split(","):
        raw = raw.strip()
        if raw:
            try:
                result.add(int(raw))
            except ValueError:
                raise ValueError(f"{name}: {raw!r} не является числовым ID") from None
    return result


def build_service() -> ShoppingService:
    database_path = Path(os.getenv("DATABASE_PATH", "data/shopping.db"))
    catalog_path = Path(os.getenv("CATALOG_PATH", "data/catalog.csv"))
    return ShoppingService(Database(database_path), Catalog(catalog_path))


async def run_bots(service: ShoppingService) -> None:
    telegram_token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    max_token = os.getenv("MAX_BOT_TOKEN", "").strip()
    shared_key = os.getenv("SHARED_LIST_KEY", "").strip()
    tasks = []
    if telegram_token:
        from app.telegram_bot import run_telegram

        allowed = ids_from_env("ALLOWED_TELEGRAM_IDS")
        if shared_key and not allowed:
            raise ValueError("Для SHARED_LIST_KEY задайте ALLOWED_TELEGRAM_IDS")
        tasks.append(run_telegram(telegram_token, service, allowed, shared_key))
    if max_token:
        from app.max_bot import run_max

        allowed = ids_from_env("ALLOWED_MAX_IDS")
        if shared_key and not allowed:
            raise ValueError("Для SHARED_LIST_KEY задайте ALLOWED_MAX_IDS")
        tasks.append(
            run_max(
                max_token,
                service,
                allowed,
                shared_key,
                os.getenv("MAX_API_BASE", "https://platform-api2.max.ru"),
            )
        )
    if not tasks:
        raise ValueError("Задайте TELEGRAM_BOT_TOKEN и/или MAX_BOT_TOKEN в .env")
    await asyncio.gather(*tasks)


def cli(service: ShoppingService) -> None:
    print("Локальный режим. Введите /help; выход — /quit.")
    while True:
        try:
            text = input("> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if text in {"/quit", "/exit"}:
            break
        try:
            print(service.handle("cli:local", text))
        except Exception:
            logging.exception("CLI request failed")


def main() -> None:
    load_dotenv()
    parser = argparse.ArgumentParser(description="Бот списка покупок и сравнения цен")
    parser.add_argument("--cli", action="store_true", help="Проверить логику в терминале")
    parser.add_argument("--check", action="store_true", help="Проверить БД и CSV-каталог")
    args = parser.parse_args()
    logging.basicConfig(
        level=os.getenv("LOG_LEVEL", "INFO"),
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    service = build_service()
    if args.check:
        print(
            f"OK: загружено предложений: {len(service.catalog.offers)}; "
            f"магазинов: {len(service.catalog.stores)}; "
            f"демо-данные: {'да' if service.catalog.has_demo else 'нет'}"
        )
        return
    if args.cli:
        cli(service)
    else:
        asyncio.run(run_bots(service))


if __name__ == "__main__":
    main()
