from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class Offer:
    store: str
    product: str
    package: str
    price_kopecks: int
    old_price_kopecks: int | None
    url: str
    updated_at: str
    is_demo: bool

    @property
    def price_rub(self) -> float:
        return self.price_kopecks / 100


@dataclass(frozen=True, slots=True)
class ShoppingItem:
    id: int
    user_key: str
    name: str
    quantity: float
    purchased: bool


def money(kopecks: int) -> str:
    """Format kopecks without floating-point rounding errors."""
    rubles, cents = divmod(kopecks, 100)
    return f"{rubles:,}.{cents:02d}".replace(",", " ").replace(".", ",") + " ₽"


def quantity(value: float) -> str:
    if value.is_integer():
        return str(int(value))
    return f"{value:g}".replace(".", ",")
