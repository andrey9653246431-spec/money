from __future__ import annotations

import sqlite3
from pathlib import Path

from .models import ShoppingItem
from .text import normalize


class Database:
    def __init__(self, path: str | Path):
        self.path = str(path)
        if self.path != ":memory:":
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
        self._memory_connection: sqlite3.Connection | None = None
        if self.path == ":memory:":
            self._memory_connection = self._connect()
        self.init_schema()

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=10)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        if self.path != ":memory:":
            connection.execute("PRAGMA journal_mode = WAL")
        return connection

    def _connection(self) -> sqlite3.Connection:
        return self._memory_connection or self._connect()

    @staticmethod
    def _close(connection: sqlite3.Connection, persistent: sqlite3.Connection | None) -> None:
        if connection is not persistent:
            connection.close()

    def init_schema(self) -> None:
        connection = self._connection()
        try:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS shopping_items (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_key TEXT NOT NULL,
                    name TEXT NOT NULL,
                    normalized_name TEXT NOT NULL,
                    quantity REAL NOT NULL DEFAULT 1 CHECK(quantity > 0),
                    purchased INTEGER NOT NULL DEFAULT 0,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE(user_key, normalized_name)
                );
                CREATE INDEX IF NOT EXISTS idx_shopping_user
                    ON shopping_items(user_key, purchased, id);
                """
            )
            connection.commit()
        finally:
            self._close(connection, self._memory_connection)

    def add(self, user_key: str, name: str, amount: float = 1) -> ShoppingItem:
        name = " ".join(name.split()).strip()
        if not name:
            raise ValueError("Название товара не может быть пустым")
        if len(name) > 200:
            raise ValueError("Название товара слишком длинное (максимум 200 символов)")
        if amount <= 0 or amount > 999:
            raise ValueError("Количество должно быть больше 0 и не больше 999")
        key = normalize(name)
        connection = self._connection()
        try:
            connection.execute(
                """
                INSERT INTO shopping_items(user_key, name, normalized_name, quantity)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(user_key, normalized_name) DO UPDATE SET
                    quantity = quantity + excluded.quantity,
                    purchased = 0
                """,
                (user_key, name, key, amount),
            )
            connection.commit()
            row = connection.execute(
                "SELECT * FROM shopping_items WHERE user_key = ? AND normalized_name = ?",
                (user_key, key),
            ).fetchone()
            return self._item(row)
        finally:
            self._close(connection, self._memory_connection)

    def items(self, user_key: str, *, include_purchased: bool = True) -> list[ShoppingItem]:
        connection = self._connection()
        try:
            where = "user_key = ?" if include_purchased else "user_key = ? AND purchased = 0"
            rows = connection.execute(
                f"SELECT * FROM shopping_items WHERE {where} ORDER BY id", (user_key,)
            ).fetchall()
            return [self._item(row) for row in rows]
        finally:
            self._close(connection, self._memory_connection)

    def resolve(self, user_key: str, reference: str) -> ShoppingItem:
        items = self.items(user_key)
        reference = reference.strip()
        if reference.isdigit():
            for item in items:
                if item.id == int(reference):
                    return item
            raise ValueError(f"Позиции с номером {reference} нет в списке")
        key = normalize(reference)
        exact = [item for item in items if normalize(item.name) == key]
        if exact:
            return exact[0]
        partial = [
            item
            for item in items
            if key and (key in normalize(item.name) or normalize(item.name) in key)
        ]
        if len(partial) == 1:
            return partial[0]
        if len(partial) > 1:
            names = ", ".join(f"{item.id}: {item.name}" for item in partial)
            raise ValueError(f"Найдено несколько позиций. Уточните номер: {names}")
        raise ValueError(f"Позиция «{reference}» не найдена")

    def remove(self, user_key: str, reference: str) -> ShoppingItem:
        item = self.resolve(user_key, reference)
        connection = self._connection()
        try:
            connection.execute(
                "DELETE FROM shopping_items WHERE id = ? AND user_key = ?", (item.id, user_key)
            )
            connection.commit()
            return item
        finally:
            self._close(connection, self._memory_connection)

    def set_purchased(self, user_key: str, reference: str, purchased: bool = True) -> ShoppingItem:
        item = self.resolve(user_key, reference)
        connection = self._connection()
        try:
            connection.execute(
                "UPDATE shopping_items SET purchased = ? WHERE id = ? AND user_key = ?",
                (int(purchased), item.id, user_key),
            )
            connection.commit()
        finally:
            self._close(connection, self._memory_connection)
        return ShoppingItem(item.id, item.user_key, item.name, item.quantity, purchased)

    def clear(self, user_key: str) -> int:
        connection = self._connection()
        try:
            cursor = connection.execute("DELETE FROM shopping_items WHERE user_key = ?", (user_key,))
            connection.commit()
            return cursor.rowcount
        finally:
            self._close(connection, self._memory_connection)

    @staticmethod
    def _item(row: sqlite3.Row) -> ShoppingItem:
        return ShoppingItem(
            id=row["id"],
            user_key=row["user_key"],
            name=row["name"],
            quantity=float(row["quantity"]),
            purchased=bool(row["purchased"]),
        )
