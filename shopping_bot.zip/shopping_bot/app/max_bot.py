from __future__ import annotations

import asyncio
import logging
from typing import Any

import aiohttp

from .service import ShoppingService
from .telegram_bot import identity
from .text import split_message

logger = logging.getLogger(__name__)


class MaxAuthError(RuntimeError):
    pass


class MaxClient:
    """Small official REST API client; Long Polling is intended for development."""

    def __init__(self, session: aiohttp.ClientSession, token: str, base_url: str):
        self.session = session
        self.base_url = base_url.rstrip("/")
        self.headers = {"Authorization": token}

    async def _json(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        async with self.session.request(
            method, self.base_url + path, headers=self.headers, **kwargs
        ) as response:
            body = await response.text()
            if response.status in {401, 403}:
                raise MaxAuthError(f"MAX authentication failed ({response.status})")
            if response.status >= 400:
                raise RuntimeError(f"MAX API {response.status}: {body[:500]}")
            if not body:
                return {}
            return await response.json()

    async def updates(self, marker: int | None) -> dict[str, Any]:
        params: dict[str, Any] = {"timeout": 25, "limit": 100}
        if marker is not None:
            params["marker"] = marker
        return await self._json("GET", "/updates", params=params)

    async def send(self, user_id: int, text: str) -> None:
        for chunk in split_message(text):
            await self._json(
                "POST",
                "/messages",
                params={"user_id": user_id},
                json={"text": chunk},
            )


async def run_max(
    token: str,
    service: ShoppingService,
    allowed_ids: set[int],
    shared_list_key: str = "",
    base_url: str = "https://platform-api2.max.ru",
) -> None:
    timeout = aiohttp.ClientTimeout(total=40, connect=10)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        client = MaxClient(session, token, base_url)
        await client._json("GET", "/me")  # Fail early on an invalid token.
        marker: int | None = None
        logger.info("MAX long polling started (development mode)")
        while True:
            try:
                payload = await client.updates(marker)
                if payload.get("marker") is not None:
                    marker = int(payload["marker"])
                for update in payload.get("updates", []):
                    await _handle_update(client, service, allowed_ids, shared_list_key, update)
            except MaxAuthError:
                raise
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.exception("MAX polling iteration failed; retrying in 3 seconds")
                await asyncio.sleep(3)


async def _handle_update(
    client: MaxClient,
    service: ShoppingService,
    allowed_ids: set[int],
    shared_list_key: str,
    update: dict[str, Any],
) -> None:
    update_type = update.get("update_type")
    if update_type == "bot_started":
        user_id = (update.get("user") or {}).get("user_id")
        text = "/start"
    elif update_type == "message_created":
        message = update.get("message") or {}
        user_id = (message.get("sender") or {}).get("user_id")
        text = (message.get("body") or {}).get("text") or ""
        if not text:
            return
    else:
        return
    if not isinstance(user_id, int):
        return
    if allowed_ids and user_id not in allowed_ids:
        await client.send(user_id, "Доступ к этому личному боту ограничен.")
        return
    try:
        response = service.handle(identity("max", user_id, shared_list_key), text)
    except Exception:
        logger.exception("MAX request failed")
        response = "Произошла внутренняя ошибка. Попробуйте ещё раз позже."
    await client.send(user_id, response)
