"""Shared shopping-list and price-comparison service."""

__version__ = "0.1.0"
