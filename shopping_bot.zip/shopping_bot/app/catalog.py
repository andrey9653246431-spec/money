from __future__ import annotations

import csv
from decimal import Decimal, InvalidOperation
from pathlib import Path

from .models import Offer
from .text import normalize


class CatalogError(ValueError):
    pass


def _kopecks(value: str, *, field: str, line: int, required: bool = True) -> int | None:
    value = value.strip()
    if not value and not required:
        return None
    try:
        amount = Decimal(value.replace(",", "."))
        kopecks = int(amount * 100)
        if amount < 0 or amount * 100 != kopecks:
            raise InvalidOperation
        return kopecks
    except (InvalidOperation, ValueError):
        raise CatalogError(f"Строка {line}: некорректное поле {field}: {value!r}") from None


def _boolean(value: str, *, line: int) -> bool:
    normalized = value.strip().casefold()
    if normalized in {"true", "1", "yes", "да"}:
        return True
    if normalized in {"false", "0", "no", "нет", ""}:
        return False
    raise CatalogError(f"Строка {line}: is_demo должно быть true или false")


class Catalog:
    """CSV-backed price provider.

    It deliberately does not scrape retailer websites. Replace the CSV with verified
    data or add a separate provider that writes the same schema.
    """

    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.offers = self._load()

    def _load(self) -> list[Offer]:
        if not self.path.exists():
            raise CatalogError(f"Каталог не найден: {self.path}")
        required = {
            "store",
            "product",
            "package",
            "price_rub",
            "old_price_rub",
            "url",
            "updated_at",
            "is_demo",
        }
        offers: list[Offer] = []
        with self.path.open("r", encoding="utf-8-sig", newline="") as file:
            reader = csv.DictReader(file)
            missing = required - set(reader.fieldnames or [])
            if missing:
                raise CatalogError("В CSV нет колонок: " + ", ".join(sorted(missing)))
            for line, row in enumerate(reader, start=2):
                store = (row["store"] or "").strip()
                product = (row["product"] or "").strip()
                package = (row["package"] or "").strip()
                updated_at = (row["updated_at"] or "").strip()
                if not store or not product or not package or not updated_at:
                    raise CatalogError(
                        f"Строка {line}: store, product, package и updated_at обязательны"
                    )
                price = _kopecks(row["price_rub"] or "", field="price_rub", line=line)
                if price <= 0:
                    raise CatalogError(f"Строка {line}: price_rub должен быть больше 0")
                old_price = _kopecks(
                    row["old_price_rub"] or "",
                    field="old_price_rub",
                    line=line,
                    required=False,
                )
                offers.append(
                    Offer(
                        store=store,
                        product=product,
                        package=package,
                        price_kopecks=price,
                        old_price_kopecks=old_price,
                        url=(row["url"] or "").strip(),
                        updated_at=updated_at,
                        is_demo=_boolean(row["is_demo"] or "", line=line),
                    )
                )
        if not offers:
            raise CatalogError("Каталог пуст")
        return offers

    @property
    def has_demo(self) -> bool:
        return any(offer.is_demo for offer in self.offers)

    @property
    def stores(self) -> list[str]:
        return sorted({offer.store for offer in self.offers}, key=str.casefold)

    def search(self, query: str, limit: int = 30) -> list[Offer]:
        query_key = normalize(query)
        tokens = query_key.split()
        if not tokens:
            return []
        scored: list[tuple[float, int, Offer]] = []
        for offer in self.offers:
            haystack = normalize(f"{offer.product} {offer.package} {offer.store}")
            product_key = normalize(offer.product)
            product_tokens = set(product_key.split())
            query_tokens = set(tokens)
            overlap = len(query_tokens & product_tokens) / len(query_tokens)
            if query_key == product_key:
                score = 140.0
            elif query_key in haystack:
                score = 120.0
            elif query_tokens.issubset(product_tokens):
                score = 110.0
            elif overlap == 1:
                score = 100.0
            elif overlap >= 0.5:
                score = 60.0 * overlap
            else:
                continue
            # Prefer close textual matches, then cheaper offers.
            score -= abs(len(product_key) - len(query_key)) * 0.05
            scored.append((score, offer.price_kopecks, offer))
        scored.sort(key=lambda value: (-value[0], value[1], value[2].store.casefold()))
        return [offer for _, _, offer in scored[:limit]]

    def best_by_store(self, query: str) -> dict[str, Offer]:
        best: dict[str, Offer] = {}
        for offer in self.search(query, limit=500):
            current = best.get(offer.store)
            if current is None or offer.price_kopecks < current.price_kopecks:
                best[offer.store] = offer
        return dict(sorted(best.items(), key=lambda pair: pair[1].price_kopecks))
