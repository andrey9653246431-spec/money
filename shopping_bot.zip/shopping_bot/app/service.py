from __future__ import annotations

from decimal import Decimal, InvalidOperation

from .catalog import Catalog
from .database import Database
from .models import Offer, money, quantity


HELP = """Команды:
/add молоко 3,2% — добавить 1 позицию
/add 2 молоко 3,2% — добавить 2 позиции
/list — показать список
/remove 1 — удалить позицию по номеру из /list
/bought 1 — отметить купленной
/return 1 — вернуть в покупки
/compare молоко 3,2% — сравнить один товар
/compare — сравнить активный список
/total — посчитать ориентировочную сумму
/send — прислать список в этот личный чат
/clear — очистить список
/stores — магазины в загруженном каталоге
/id — показать ваш ключ пользователя
/help — помощь

Можно писать без команды: «Добавь хлеб» или «2 яйца».
Цена и наличие зависят от города, магазина и времени обновления."""


class ShoppingService:
    def __init__(self, database: Database, catalog: Catalog):
        self.database = database
        self.catalog = catalog

    def handle(self, user_key: str, text: str) -> str:
        text = (text or "").strip()
        if not text:
            return "Отправьте команду /help или название товара."
        command, _, argument = text.partition(" ")
        command = command.split("@", 1)[0].casefold()
        argument = argument.strip()
        try:
            if command in {"/start", "/help", "помощь"}:
                return HELP
            if command == "/id":
                return f"Ваш ключ пользователя: {user_key}"
            if command in {"/add", "добавь", "добавить", "+"}:
                return self._add(user_key, argument)
            if command in {"/list", "/список", "список"}:
                return self.format_list(user_key)
            if command in {"/remove", "/delete", "/удали", "удали", "удалить", "-"}:
                return self._remove(user_key, argument)
            if command in {"/bought", "/куплено", "куплено"}:
                return self._purchased(user_key, argument, True)
            if command in {"/return", "/вернуть", "вернуть"}:
                return self._purchased(user_key, argument, False)
            if command in {"/compare", "/сравни", "сравни"}:
                return self.compare_one(argument) if argument else self.compare_list(user_key)
            if command in {"/total", "/итог", "итог"}:
                return self.total(user_key)
            if command in {"/send", "/отправь", "отправь", "пришли"}:
                return "📋 Ваш список покупок\n\n" + self.format_list(user_key)
            if command in {"/clear", "/очистить", "очистить"}:
                count = self.database.clear(user_key)
                return f"Список очищен. Удалено позиций: {count}."
            if command in {"/stores", "/магазины", "магазины"}:
                return "Магазины в каталоге:\n• " + "\n• ".join(self.catalog.stores)
            if command.startswith("/"):
                return "Не знаю такую команду. Откройте /help."
            # Friendly shorthand: “2 молока” or a bare product name adds an item.
            return self._add(user_key, text)
        except ValueError as error:
            return str(error)
        except Exception:
            # Adapters log the exception with traceback; users get no internals.
            raise

    def _add(self, user_key: str, argument: str) -> str:
        if not argument:
            raise ValueError("Укажите товар: /add молоко 3,2%")
        amount, name = self._parse_amount(argument)
        item = self.database.add(user_key, name, amount)
        return f"Добавлено: {item.name} — {quantity(item.quantity)} шт. (№{item.id})."

    @staticmethod
    def _parse_amount(argument: str) -> tuple[float, str]:
        first, separator, rest = argument.partition(" ")
        if separator:
            try:
                value = Decimal(first.replace(",", "."))
                if value > 0:
                    return float(value), rest.strip()
            except InvalidOperation:
                pass
        return 1.0, argument.strip()

    def _remove(self, user_key: str, argument: str) -> str:
        if not argument:
            raise ValueError("Укажите номер или название: /remove 1")
        item = self.database.remove(user_key, argument)
        return f"Удалено: {item.name}."

    def _purchased(self, user_key: str, argument: str, purchased: bool) -> str:
        if not argument:
            raise ValueError("Укажите номер или название позиции")
        item = self.database.set_purchased(user_key, argument, purchased)
        return ("Отмечено купленным: " if purchased else "Возвращено в список: ") + item.name + "."

    def format_list(self, user_key: str) -> str:
        items = self.database.items(user_key)
        if not items:
            return "Список пуст. Добавьте товар: /add молоко 3,2%"
        lines = []
        for item in items:
            mark = "✅" if item.purchased else "☐"
            lines.append(f"{mark} {item.id}. {item.name} — {quantity(item.quantity)} шт.")
        active = sum(not item.purchased for item in items)
        return "\n".join(lines) + f"\n\nОсталось купить: {active} из {len(items)}."

    def _source_notice(self, offers: list[Offer]) -> str:
        notices = []
        if any(offer.is_demo for offer in offers):
            notices.append("⚠️ ДЕМО-ЦЕНЫ: это тестовые данные, а не актуальные цены магазинов.")
        timestamps = [offer.updated_at for offer in offers if offer.updated_at]
        if timestamps:
            notices.append(f"Самая ранняя дата данных в выдаче: {min(timestamps)}.")
        notices.append("Перед покупкой проверьте цену, фасовку и наличие в магазине.")
        return "\n".join(notices)

    @staticmethod
    def _offer_line(offer: Offer) -> str:
        old = f" (старая цена: {money(offer.old_price_kopecks)})" if offer.old_price_kopecks else ""
        return (
            f"• {offer.store}: {offer.product}, {offer.package} — "
            f"{money(offer.price_kopecks)}{old}"
        )

    def compare_one(self, query: str) -> str:
        offers = list(self.catalog.best_by_store(query).values())
        if not offers:
            return f"В загруженном каталоге ничего не найдено по запросу «{query}»."
        lines = [self._offer_line(offer) for offer in offers[:10]]
        return f"🔎 {query}\n" + "\n".join(lines) + "\n\n" + self._source_notice(offers)

    def compare_list(self, user_key: str) -> str:
        items = self.database.items(user_key, include_purchased=False)
        if not items:
            return "Нет активных позиций. Добавьте товар: /add молоко 3,2%"
        sections: list[str] = []
        all_offers: list[Offer] = []
        for item in items:
            offers = list(self.catalog.best_by_store(item.name).values())
            if not offers:
                sections.append(f"{item.id}. {item.name}: не найдено")
                continue
            all_offers.extend(offers)
            sections.append(
                f"{item.id}. {item.name} × {quantity(item.quantity)}\n"
                + "\n".join(self._offer_line(offer) for offer in offers[:5])
            )
        return "\n\n".join(sections) + "\n\n" + self._source_notice(all_offers)

    def total(self, user_key: str) -> str:
        items = self.database.items(user_key, include_purchased=False)
        if not items:
            return "Нет активных позиций для подсчёта."
        cheapest_total = 0
        missing: list[str] = []
        per_item: list[str] = []
        store_totals: dict[str, int] = {}
        store_missing: dict[str, list[str]] = {store: [] for store in self.catalog.stores}
        used_offers: list[Offer] = []
        for item in items:
            multiplier = Decimal(str(item.quantity))
            offers = self.catalog.best_by_store(item.name)
            if not offers:
                missing.append(item.name)
                for store in store_missing:
                    store_missing[store].append(item.name)
                continue
            cheapest = next(iter(offers.values()))
            used_offers.append(cheapest)
            item_price = int(Decimal(cheapest.price_kopecks) * multiplier)
            cheapest_total += item_price
            per_item.append(f"• {item.name}: {money(item_price)} — {cheapest.store}")
            for store in self.catalog.stores:
                offer = offers.get(store)
                if offer is None:
                    store_missing[store].append(item.name)
                else:
                    store_totals[store] = store_totals.get(store, 0) + int(
                        Decimal(offer.price_kopecks) * multiplier
                    )
        lines = ["Ориентировочный итог активного списка:", *per_item]
        lines.append(f"\nМинимум по позициям (возможно, в разных магазинах): {money(cheapest_total)}")
        complete = [
            (store, total)
            for store, total in store_totals.items()
            if not store_missing[store] and not missing
        ]
        if complete:
            lines.append("\nВесь найденный список в одном магазине:")
            lines.extend(f"• {store}: {money(total)}" for store, total in sorted(complete, key=lambda x: x[1]))
        if missing:
            lines.append("\nНе найдено: " + ", ".join(missing))
        lines.append("\n" + self._source_notice(used_offers))
        lines.append("Итог не включает доставку, депозитную тару и персональные скидки.")
        return "\n".join(lines)
