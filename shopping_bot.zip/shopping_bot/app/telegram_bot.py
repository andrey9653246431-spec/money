from __future__ import annotations

import logging

from aiogram import Bot, Dispatcher, F
from aiogram.types import BotCommand, Message

from .service import ShoppingService
from .text import split_message

logger = logging.getLogger(__name__)


def identity(platform: str, user_id: int, shared_list_key: str = "") -> str:
    return shared_list_key.strip() or f"{platform}:{user_id}"


async def run_telegram(
    token: str,
    service: ShoppingService,
    allowed_ids: set[int],
    shared_list_key: str = "",
) -> None:
    bot = Bot(token=token)
    dispatcher = Dispatcher()

    @dispatcher.message(F.text)
    async def on_text(message: Message) -> None:
        user = message.from_user
        if user is None:
            return
        if allowed_ids and user.id not in allowed_ids:
            await message.answer("Доступ к этому личному боту ограничен.")
            return
        try:
            response = service.handle(identity("telegram", user.id, shared_list_key), message.text or "")
        except Exception:
            logger.exception("Telegram request failed")
            response = "Произошла внутренняя ошибка. Попробуйте ещё раз позже."
        for chunk in split_message(response):
            await message.answer(chunk)

    await bot.set_my_commands(
        [
            BotCommand(command="add", description="Добавить товар"),
            BotCommand(command="list", description="Список покупок"),
            BotCommand(command="compare", description="Сравнить цены"),
            BotCommand(command="total", description="Итоговая сумма"),
            BotCommand(command="send", description="Прислать список себе"),
            BotCommand(command="clear", description="Очистить список"),
            BotCommand(command="help", description="Все команды"),
        ]
    )
    logger.info("Telegram polling started")
    await dispatcher.start_polling(bot)
