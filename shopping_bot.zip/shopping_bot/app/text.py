import re
import unicodedata


def normalize(value: str) -> str:
    value = unicodedata.normalize("NFKC", value).casefold().replace("ё", "е")
    value = value.replace("%", " % ")
    value = re.sub(r"[^0-9a-zа-я%]+", " ", value)
    return " ".join(value.split())


def split_message(text: str, limit: int = 3500) -> list[str]:
    """Split long replies at line boundaries for messenger limits."""
    if len(text) <= limit:
        return [text]
    chunks: list[str] = []
    current = ""
    for line in text.splitlines(keepends=True):
        if len(line) > limit:
            if current:
                chunks.append(current.rstrip())
                current = ""
            chunks.extend(line[i : i + limit] for i in range(0, len(line), limit))
        elif len(current) + len(line) > limit:
            chunks.append(current.rstrip())
            current = line
        else:
            current += line
    if current.strip():
        chunks.append(current.rstrip())
    return chunks
