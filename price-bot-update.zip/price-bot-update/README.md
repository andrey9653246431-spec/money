# Бот сравнения цен — обновление для `andrey9653246431-spec/money`

Telegram-бот: сравнение цен в топ-10 супермаркетах РФ (Купер), корзина, список покупок в чат/файлом/email. Полная пошаговая инструкция — `PRICE_BOT_SETUP.md`.

## Файлы пакета (сохраняйте пути)

```text
price_bot/__init__.py
price_bot/bot.py
price_bot/config.py
price_bot/kuper.py
price_bot/edadil.py
price_bot/store.py
price_bot/mailer.py
price_bot/requirements.txt
.github/workflows/price-bot.yml
templates/github/price-bot.yml
tests/test_price_bot.py
state/bot/.gitkeep
docs/INTEGRATION.md
README.md
PRICE_BOT_SETUP.md
```

Минимально необходимы `price_bot/` и `.github/workflows/price-bot.yml`.

## Кратко

1. Создайте бота через @BotFather, скопируйте токен.
2. Добавьте файлы из пакета в репозиторий, commit в `main`.
3. Secrets: `PRICE_BOT_TOKEN`. Variables: `PRICE_BOT_ENABLED=false` (потом `true`), `BOT_LAT`/`BOT_LON` — необязательно.
4. Actions → **Price comparison bot** → Run workflow (5 минут) → проверьте в Telegram: `/start`, `молоко`, корзина, список, файл.
5. `PRICE_BOT_ENABLED=true` — сессии каждый час по ~50 минут.

## Проверено

- Ruff и форматирование: без ошибок;
- 35 pytest-тестов (27 старых + 8 новых);
- живой поиск Купера: 7 магазинов из топ-10, сортировка по цене за единицу, акции;
- сценарий бота с фейковым Telegram API: поиск → корзина → список → файл;
- YAML workflow разобран.
